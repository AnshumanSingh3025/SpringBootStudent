package com.MyRestapi.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.MyRestapi.Model.Student;
import com.MyRestapi.repository.MyRestApiRepo;

@Service
public class MyRestApiService {
	@Autowired
MyRestApiRepo repo;
	public ResponseEntity<String> addStudent(Student stud) {
	try {
		repo.save(stud);
		return new ResponseEntity<>("ok,1 row effected",HttpStatus.CREATED);
	} catch (Exception e) {
		e.printStackTrace();
	}
		return new ResponseEntity<>("failed",HttpStatus.NOT_ACCEPTABLE);
	}
	public ResponseEntity<List<Student>> getStudent() {
		try {
	
			return new ResponseEntity<>(repo.findAll(),HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
			return new ResponseEntity<>(new ArrayList<>(),HttpStatus.BAD_REQUEST);
		}
	public ResponseEntity<String> updateStudent(Student stud) {
		try {
			repo.save(stud);
			return new ResponseEntity<>("ok,1 row effected",HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>("failed",HttpStatus.NOT_ACCEPTABLE);
	}
	public ResponseEntity<String> deleteStudent(int rollno) {
		try {
			repo.deleteById(rollno);
			return new ResponseEntity<>("ok,1 row effected",HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>("failed",HttpStatus.NOT_ACCEPTABLE);
	}
}