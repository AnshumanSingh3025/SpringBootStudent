package com.MyRestapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.MyRestapi.Model.Student;

@Repository
public interface MyRestApiRepo extends JpaRepository<Student,Integer > {

}
