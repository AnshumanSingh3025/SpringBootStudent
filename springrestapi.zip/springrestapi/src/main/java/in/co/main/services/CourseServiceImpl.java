package in.co.main.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import in.co.main.controller.entities.course;


@Service
public class CourseServiceImpl implements CourseService {
	
	List<course> list;
	
	public CourseServiceImpl() {
		list = new ArrayList<>();
		list.add(new course(145,"Core Java","This is course of java."));
		list.add(new course(146,"Adv Java","This is course of adv java."));
		list.add(new course(147 ,"DBMS","This is course of dbms."));
	}

	@Override
	public List<course> getCourses() {
		// TODO Auto-generated method stub
		return list;
	}

	@Override
	public course getCourse(long courseId) {
		course c= null;
		for(course course:list)
		{
			if(course.getId()==courseId)
			{
				c=course;
				break;
			}
		}
		return c;
	}

	@Override
	public course addCourse(course course) {
		list.add(course);
		return course;
	}

	@Override
	public course putCourse(course course) {
		list.add(course);
		return course;
	}


}
