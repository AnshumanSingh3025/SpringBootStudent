package in.co.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import in.co.main.controller.entities.course;
import in.co.main.services.CourseService;

@RestController
public class myController {

	@Autowired
	private CourseService CourseServices;

	@GetMapping("/home")
	public String home() {
		return "Welcome to courses Application.";
	}

	// get courses

	@GetMapping("/courses")
	public List<course> getCourses() {
		return this.CourseServices.getCourses();
	}
	
	@GetMapping("/courses/{courseId}")
	public course getCourse(@PathVariable String courseId)
	{
		return this.CourseServices.getCourse(Long.parseLong(courseId));
	}
	
	@PostMapping("/courses")
	public course addCourse(@RequestBody course course)
	{
		return this.CourseServices.addCourse(course);
	}
	
	@PutMapping("/courses")
	public course putCourse(@RequestBody course course)
	{
		return this.CourseServices.putCourse(course);
	}

}
