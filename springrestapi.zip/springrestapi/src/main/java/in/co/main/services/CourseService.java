package in.co.main.services;

import java.util.List;

import in.co.main.controller.entities.course;

public interface CourseService {

	public List<course> getCourses();
	
	public course getCourse(long courseId);
	
	public course addCourse(course course);
	
	public course putCourse(course course);
}
